function date_str = get_date()

date_str = datestr(datetime('now'), 'dd-mmm_HH_MM_SS'); 
