fig1; 
fig2; 
fig3; 
fig4; 
fig5; 